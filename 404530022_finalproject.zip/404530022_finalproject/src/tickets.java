import java.util.Scanner;
import java.lang.*;

public class tickets {
	
	public static void main (String[] args)
	{
		int [][]x = {{10,10,10,10,10,10,10,10,10,10},
					 {10,10,10,10,10,10,10,10,10,10},
					 {10,10,10,10,10,10,10,10,10,10},
					 {10,10,20,20,20,20,20,20,10,10},
					 {10,10,20,20,20,20,20,20,10,10},
					 {10,10,20,20,20,20,20,20,10,10},
					 {20,20,30,30,40,40,30,30,20,20},
					 {20,30,30,40,50,50,40,30,30,20},
					 {30,40,50,50,50,50,50,50,40,30}};
		
		for(int p = 0; p < x.length; p++)
		{
			for(int q = 0; q < x[0].length; q++)
			{
			System.out.print(x[p][q]);
			System.out.print(" ");
			}
			System.out.println("");
		}
		
		try{
			
		Scanner a = new Scanner(System.in);
		System.out.print("choose a service 1.buy ticket 2.check seat 3.exit");
		int choose = a.nextInt();
	
			if (choose == 1 || choose == 2 || choose == 3){
			
				switch(choose){
		
				case 1:
					
					Scanner b = new Scanner(System.in);
					System.out.print("please choose a row (from 1 ~ 9)");
					int row = b.nextInt()-1;
					System.out.print("please choose a column (from 1 ~ 10)");
					int col = b.nextInt()-1;
				
					if (row >= 0 || row <= 8 || col >= 0 || col <= 9 || x[row][col] != 0)
					{
						System.out.println("the price is " + x[row][col]);
						System.out.println("thanks for buying");
						System.out.println("");
						x[row][col] = 0;
						
						for(int p = 0; p < x.length; p++)
						{
							for(int q = 0; q < x[0].length; q++)
							{
							System.out.print(x[p][q]);
							System.out.print(" ");
							}
							System.out.println("");
						}
					}
					else
					{
						System.out.print("choose the wrong seat");
					}
					
					break;
					
				case 2:
					
					Scanner c = new Scanner(System.in);
					System.out.print("which price do you want to buy");
					int price = c.nextInt();
					
					if(price == 10 || price == 20 || price == 30 || price == 40 || price == 50)
					{
						
						if (price == 10)
						{
							int r, s;
							for(r = 0; r <= 8; r++)
							{
								for(s = 0; s <= 9; s++)
								{
									if (x[r][s] == 10)
									{
										System.out.println("row = " + (r+1) + " column =  " + (s+1) );
									}
								}
							}
						}
						
						if (price == 20)
						{
							int r, s;
							for(r = 0; r <= 8; r++)
							{
								for(s = 0; s <= 9; s++)
								{
									if (x[r][s] == 20)
									{
										System.out.println("row = " + (r+1) + " column =  " + (s+1) );
									}
								}
							}
						}
						
						if (price == 30)
						{
							int r, s;
							for(r = 0; r <= 8; r++)
							{
								for(s = 0; s <= 9; s++)
								{
									if (x[r][s] == 30)
									{
										System.out.println("row = " + (r+1) + " column =  " + (s+1) );
									}
								}
							}
						}
						
						if (price == 40)
						{
							int r, s;
							for(r = 0; r <= 8; r++)
							{
								for(s = 0; s <= 9; s++)
								{
									if (x[r][s] == 40)
									{
										System.out.println("row = " + (r+1) + " column =  " + (s+1) );
									}
								}
							}
						}
						
						if (price == 50)
						{
							int r, s;
							for(r = 0; r <= 8; r++)
							{
								for(s = 0; s <= 9; s++)
								{
									if (x[r][s] == 50)
									{
										System.out.println("row = " + (r+1) + " column =  " + (s+1) );
									}
								}
							}
						}
					}
					else
					{
						System.out.println("wrong price");
					}
					
					break;
					
				case 3:
					
					System.out.print("thanks for using");
					System.out.println("");
					}
				}
			
			else
				{
					System.out.print("wrong choose");
				}
			}
		
			catch (Exception e){
				System.out.println("error");
				System.exit(0);
		}
	}
}
