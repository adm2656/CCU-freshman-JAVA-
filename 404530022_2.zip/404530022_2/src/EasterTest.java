
public class EasterTest 
{
	public static void main(String[] args)
	{
		String easterStr1, easterStr2;
		easterStr1 = Easter.calculateEaster(2001);
		easterStr2 = Easter.calculateEaster(2012);
		
		System.out.println("In 2001, " + easterStr1);
		System.out.println("In 2012, " + easterStr2);
	}
}
