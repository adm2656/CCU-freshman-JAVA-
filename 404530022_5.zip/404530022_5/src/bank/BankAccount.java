package bank;

import java.util.ArrayList;

public class BankAccount {
    String state;
    int accountNumber;
    public double balance;
    public ArrayList<Double> TransactionList = null;
    
    public BankAccount(){
        this(-1,-1);
    }
    
    public BankAccount(int anAccountNumber){
        this(anAccountNumber, 0);
    }
    
    public BankAccount(int anAccountNumber, double initialBalance){
        this.state = "open";
        this.accountNumber = anAccountNumber;
        this.balance = initialBalance;
        this.TransactionList = new ArrayList<Double>();
    }

    private boolean isOpen(){
        return this.state.equalsIgnoreCase("open");
    }

    private boolean isSuspend(){
        return this.state.equalsIgnoreCase("suspend");
    }

    private boolean isClosed(){
        return this.state.equalsIgnoreCase("closed");
    }
    
    void reOpen(){
        this.state = "open";
    }
    
    void suspend(){
        this.state = "suspend";
    }
    
    void close(){
        this.state = "closed";
    }

    void deposit(double amount){
        if(!isOpen() || amount < 0){
        }else{
            this.balance = this.balance + amount;
            addTransaction(amount);
        }
    }
    void withdraw(double amount){
        if(!isOpen() || amount < 0 || amount > this.balance){
        }else{
            this.balance = this.balance - amount;
            addTransaction(0 - amount);
        }            
    }
    
    void addTransaction(double amount){
        this.TransactionList.add(amount);
    }
    
    String getTransactions(){
        String rlt = "";
        for(int i = 0 ; i < this.TransactionList.size() ; i++){
            rlt = rlt + (i+1)+ ": " +this.TransactionList.get(i)+"\n";
        }
        return rlt;
    }

    double getBalance(){
        return this.balance;
    }
    
    int retrieveNumberOfTransactions(){
        return this.TransactionList.size();
    }
    
    public boolean equals(Object o){
        if(this.balance - other.balance) < 0.1)
            return true;
    }
}

public class CheckingAccount extends BankAccount{
    double Fee = 2.0;
    public CheckingAccount(int accountNumber, double initialBalance){
        super.accountNumber = accountNumber;
        super.balance = initialBalance;
    }
    
    public void deposit (double amount){
            balance = balance + amount;
            if (amount != 0)
            addTransaction(0 - amount);        
    }
    
    public void withdraw(double amount){
            balance = balance - amount;
            if (amount != 0)
            addTransaction(0 - amount);
        }
    
    public void deductFees(){        
        if( Fee > balance)
            Fee = 0;
    }
}

public class SavingsAccount extends BankAccount{
    public SavingsAccount(int accountNumber, double initialBalance, double interestRate){
        super.accountNumber = accountNumber;
        super.balance = initialBalance;
        interestRate = 0.1;
    }
    
    public void addinterest(){
        double minBalance = getBalance();
        double interest = minBalance *  0.1;
        deposit (interest);
    }
}