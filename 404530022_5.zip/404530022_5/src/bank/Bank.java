package bank;

import java.util.HashMap;

public class Bank {
	HashMap<Integer, BankAccount> BankList = new HashMap<Integer, BankAccount>();
	
	void addAccount (int accountNumber, double initalBalance){
		if(initalBalance < 0)
			initalBalance = 0;
		BankList.put(accountNumber, new BankAccount(accountNumber, initalBalance));
	}
	
	void deposit(int accountNumber, double initalBalance){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		try{
			tempAccount.deposit(initalBalance);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	void withdraw(int accountNumber, double initalBalance){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		try{
			tempAccount.deposit(initalBalance);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	double getBalance(int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		return tempAccount.getBalance();
	}
	
	String getAccountStatus(int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		return tempAccount.state;
	}
	
	String summarizeAccountTransactions(int accountNumber){
		
		StringBuffer sb = new StringBuffer();
		BankAccount tempAccount = (BankAccount)BankList.get(accountNumber);
		
		sb.append("Account #" + accountNumber + "transaction:\n\n");
		sb.append(tempAccount.getTransactions());
		sb.append("End of transactions\n");
		
		return sb.toString();
	}
	

    String summarizeAllAccounts (){
        StringBuffer sb = new StringBuffer();
        sb.append("Account\tBalance\t#Transcations\tStatus\n");
        for (BankAccount bank :BankList.values()){
            sb.append(bank.accountNumber + "\t");
            sb.append(bank.getBalance() + "\t");
            sb.append(bank.retrieveNumberOfTransactions() + "\t\t");
            sb.append(bank.state + "\n");
        }
        sb.append("End of Account Summary" + "\n");
        return sb.toString();
    }

	void suspendAccount(int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.suspend();
	}
	
	void reOpenAccount(int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.reOpen();
	}
	
	void closeAccount(int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.close();	
	}

    void addCheckingAccount(int accountNumber, double initialBalance){
    if (initialBalance < 0)
        initialBalance = 0;
        BankList.put(accountNumber, new BankAccount(accountNumber, initialBalance));
    }
    
    void addSavingsAccount(int accountNumber, double initialBalance, double interestRate){
    if (initialBalance < 0)
        initialBalance = 0;
        BankList.put(accountNumber, new BankAccount(accountNumber, initialBalance));
    }
    
    void addInterest(int accountNumber){
        BankAccount TAccount = (BankAccount) BankList.get(accountNumber);
        TAccount.addaddInterest();
    }
    
    void deductFees(int accountNumber){
        BankAccount TAccount = (BankAccount) BankList.get(accountNumber);
        TAccount.deductFees();
    }
    
    public boolean areEqualAccounts(int accountNumber1, int accountNumber2){
        if (accountNumber1.balance.equals(accountNumber2.balance))
            return true;
    }       

}

